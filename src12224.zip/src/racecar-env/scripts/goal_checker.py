#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from ackermann_msgs.msg import AckermannDriveStamped

rospy.init_node('goal_checker')

client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
client.wait_for_server()

while not rospy.is_shutdown():
    state = client.get_state()
    if state == actionlib.GoalStatus.SUCCEEDED:
        rospy.loginfo("HEDEFE ULASTI")
        break
    else:
        rospy.loginfo("HEDEFE ULASMADI. DURUMU: %s", state)
    rospy.loginfo("DURUMU: %s", state)
    rospy.sleep(1.0)  # Check periodically