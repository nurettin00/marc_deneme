#!/usr/bin/env python

import rospy, math
from geometry_msgs.msg import Twist
from ackermann_msgs.msg import AckermannDriveStamped
from ackermann_msgs.msg import AckermannDrive


wheelbase = 0.325

def convert_trans_rot_vel_to_steering_angle(v, omega, wheelbase):
  if omega == 0 or v == 0:
    return 0

  radius = v / omega
  return math.atan(wheelbase / radius)


def cmd_callback(data):

  pub = rospy.Publisher("/ackermann_cmd_mux/input/navigation", AckermannDriveStamped, queue_size=1)
  v = data.linear.x
  steering = convert_trans_rot_vel_to_steering_angle(v, data.angular.z, wheelbase)
    
  msg = AckermannDriveStamped()
  msg.header.stamp = rospy.Time.now()
  msg.header.frame_id = "odom"
  msg.drive.steering_angle = steering
  msg.drive.speed = v
    
  pub.publish(msg)

if __name__ == '__main__': 
  try:
    
    rospy.init_node('cmd_vel_to_ackermann_drive')
    # twist_cmd_topic = rospy.get_param('~twist_cmd_topic', '/cmd_vel') 
    # ackermann_cmd_topic = rospy.get_param('~ackermann_cmd_topic', '/ackermann_cmd_mux/input/teleop')
    # wheelbase = rospy.get_param('~wheelbase', 0.325)
    # frame_id = rospy.get_param('~frame_id', 'odom')
    # message_type = rospy.get_param('~message_type', 'ackermann_drive_stamped') # ackermann_drive or ackermann_drive_stamped
    
    rospy.Subscriber("/cmd_vel", Twist, cmd_callback, queue_size=1)    
    rospy.loginfo("Node 'cmd_vel_to_ackermann_drive' started.")
    
    rospy.spin()
    
  except rospy.ROSInterruptException:
    pass
